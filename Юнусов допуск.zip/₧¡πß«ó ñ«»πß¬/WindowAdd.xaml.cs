﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Юнусов_допуск.Classes;

namespace Юнусов_допуск
{
    /// <summary>
    /// Логика взаимодействия для WindowAdd.xaml
    /// </summary>
    public partial class WindowAdd : Window
    {
        public WindowAdd()
        {
            InitializeComponent();
            CmbCities.ItemsSource = ClassHelp.year;
        }

        private void BtnAddWorker_Click(object sender, RoutedEventArgs e)
        {
            ClassWorker library = new ClassWorker()
            {
                NamePredpr = TxbFullPredpr.Text,
                NameTovar = CmbCities.Text,
                SumUan = Math.Round(Convert.ToDouble(TxbFullCenOun.Text),2),
                Colvo = Convert.ToInt32(TxbFullColvo.Text),
                Obshsum = Math.Round(Convert.ToDouble(TxbFullColvo.Text) * Convert.ToDouble(TxbFullCenOun.Text),2)
            };
            ClassHelp.worker.Add(library);
            Close();
        }
        
    }
}
