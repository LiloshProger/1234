﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Юнусов_допуск.Classes;

namespace Юнусов_допуск
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CmbFiltr.ItemsSource = ClassHelp.year;

            //один объект класса ClassLibrary
            ClassWorker worker = new ClassWorker() { };
           
             ClassHelp.worker.Add(worker);

            
             DtgListWorkers.ItemsSource = ClassHelp.worker;
           

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            //переход на форму добавления
            WindowAdd windowAdd = new WindowAdd();
            windowAdd.ShowDialog();
        }

        private void MaMi_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ClassHelp.worker.OrderBy(x => x.Obshsum).ToList();
           
        }

        private void MiMa_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ClassHelp.worker.OrderByDescending(x => x.Obshsum).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //фильтр по товару
            string city = ClassHelp.year[CmbFiltr.SelectedIndex];
            if (CmbFiltr.SelectedIndex != 0)
                DtgListWorkers.ItemsSource = ClassHelp.worker.Where(x => x.NamePredpr == city).ToList();
            else
                DtgListWorkers.ItemsSource = ClassHelp.worker;
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ////Поиск 
            DtgListWorkers.ItemsSource = ClassHelp.worker.Where(x => x.NamePredpr.Contains(TxtSearch.Text)).ToList();
        }

        private void Obnov_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ClassHelp.worker.ToList();
        }

        private void Ochist_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = null;
        }

        private void Sohr_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog SohrFileDialog = new SaveFileDialog();
            if ((bool)SohrFileDialog.ShowDialog())
            {
                string file = SohrFileDialog.FileName;
                ClassHelp.SohrListToFile(file);
            }
        }
    }
}
