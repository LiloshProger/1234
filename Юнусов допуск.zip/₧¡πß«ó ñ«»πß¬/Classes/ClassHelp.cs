﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Юнусов_допуск.Classes
{
    internal class ClassHelp
    {
        public static List<ClassWorker> worker = new List<ClassWorker>();

        public static List<string> year = new List<string>()
        {
            "стол",
            "шкаф",
            "тумбочка",
            "табуретка",
            "полка"

        };
        public static void ReadList(string filename)
        {


            StreamReader sr = new StreamReader(filename, Encoding.UTF8);
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                string[] items = line.Split(';');
                ClassWorker resultse = new ClassWorker()
                {
                    NamePredpr = items[0].Trim(),
                    NameTovar = items[1].Trim(),
                    SumUan = double.Parse(items[2].Trim()),
                    Colvo = int.Parse(items[3].Trim()),
                    Obshsum = double.Parse(items[4].Trim()),

                };
                worker.Add(resultse);
            }
        }
        public static void SohrListToFile(string file)
        {
            StreamWriter streamWriter = new StreamWriter(file, false, Encoding.UTF8);
            foreach (var item in worker)
            {
                streamWriter.WriteLine($"{item.NamePredpr}; {item.NameTovar}; {item.SumUan}; {item.Colvo}; {item.Obshsum}. ");
            }
            streamWriter.Close();
        }
    }
}
