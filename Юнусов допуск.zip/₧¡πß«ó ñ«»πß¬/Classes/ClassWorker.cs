﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Юнусов_допуск.Classes
{
    internal class ClassWorker
    {
        //поля класса
        string namepredpr;
        string nametovar;
        double sumuan;
        int colvo;
        double obshsum;

        //свойства для доступа к полям
        public string NamePredpr
        { get { return namepredpr; } set { namepredpr = value; } }
        public string NameTovar
        { get { return nametovar; } set { nametovar = value; } }
        public double SumUan
        { get { return sumuan; } set { sumuan = value; } }
        public int Colvo
        { get { return colvo; } set { colvo = value; } }
        public double Obshsum
        { get { return obshsum; } set { obshsum = value; } }

       // конструкторы
        public ClassWorker()
        {
            namepredpr = string.Empty;
            nametovar = string.Empty;
            sumuan = 0.00;
            colvo = 0;
            obshsum = 0.00;
        }
        public ClassWorker(string nameP, string nameT, double sum,
            int col,double obs)
        {
            namepredpr = nameP;
            nametovar = nameT;
            sumuan = sum;
            colvo = col;
            obshsum= obs;
        }
    }
}
